import axios from 'axios';

// Substitua pela URL base da sua API
const api = axios.create({
  baseURL: 'YOUR_API_BASE_URL'
});

export type Student = {
  id: string;
  name: string;
  isPresent: boolean | null;
};

export const studentService = {
  // Buscar todos os alunos
  async getStudents(): Promise<Student[]> {
    const response = await api.get('/students');
    return response.data;
  },

  // Registrar presença do aluno
  async updateAttendance(studentId: string, isPresent: boolean): Promise<void> {
    await api.post(`/students/${studentId}/attendance`, {
      isPresent,
      date: new Date().toISOString().split('T')[0] // Data atual no formato YYYY-MM-DD
    });
  }
}; 