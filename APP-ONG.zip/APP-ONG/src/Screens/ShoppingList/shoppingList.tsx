import { View, TouchableOpacity, Text, FlatList, TextInput, Modal, Alert } from "react-native";
import { styles } from "./style";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useRouter } from "expo-router";
import { useState } from "react";

type Item = {
  id: string;
  name: string;
  value: string;
  quantity: string;
};

export const ShoppingList = () => {
  const router = useRouter();
  const [items, setItems] = useState<Item[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [newItemName, setNewItemName] = useState("");
  const [newItemValue, setNewItemValue] = useState("");
  const [newItemQuantity, setNewItemQuantity] = useState("");

  const handleValueChange = (text: string) => {
    // Remove qualquer caractere que não seja número ou ponto
    const cleanedText = text.replace(/[^0-9.]/g, '');
    
    // Garante que só haja um ponto decimal
    const parts = cleanedText.split('.');
    if (parts.length > 2) {
      return;
    }
    
    // Limita a 2 casas decimais
    if (parts[1] && parts[1].length > 2) {
      return;
    }

    setNewItemValue(cleanedText);
  };

  const handleQuantityChange = (text: string) => {
    // Remove qualquer caractere que não seja número
    const cleanedText = text.replace(/[^0-9]/g, '');
    setNewItemQuantity(cleanedText);
  };

  const handleAddItem = () => {
    if (!newItemName.trim()) {
      Alert.alert("Erro", "Por favor, insira o nome do item");
      return;
    }

    if (!newItemValue.trim()) {
      Alert.alert("Erro", "Por favor, insira o valor do item");
      return;
    }

    if (!newItemQuantity.trim()) {
      Alert.alert("Erro", "Por favor, insira a quantidade do item");
      return;
    }

    // Valida se o valor é um número válido
    const valueNumber = parseFloat(newItemValue);
    if (isNaN(valueNumber) || valueNumber <= 0) {
      Alert.alert("Erro", "Por favor, insira um valor válido maior que zero");
      return;
    }

    // Valida se a quantidade é um número válido
    const quantityNumber = parseInt(newItemQuantity);
    if (isNaN(quantityNumber) || quantityNumber <= 0) {
      Alert.alert("Erro", "Por favor, insira uma quantidade válida maior que zero");
      return;
    }

    const newItem: Item = {
      id: Date.now().toString(),
      name: newItemName.trim(),
      value: valueNumber.toFixed(2), // Formata para sempre ter 2 casas decimais
      quantity: quantityNumber.toString()
    };

    setItems([...items, newItem]);
    setNewItemName("");
    setNewItemValue("");
    setNewItemQuantity("");
    setModalVisible(false);
  };

  const handleDeleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const renderItem = ({ item }: { item: Item }) => (
    <View style={styles.itemContainer}>
      <View style={styles.itemInfo}>
        <Text style={styles.itemName}>{item.name}</Text>
        <View style={styles.itemDetails}>
          <Text style={styles.itemValue}>R$ {item.value}</Text>
          <Text style={styles.itemQuantity}>Qtd: {item.quantity}</Text>
        </View>
      </View>
      <TouchableOpacity 
        style={styles.deleteButton}
        onPress={() => handleDeleteItem(item.id)}
      >
        <AntDesign name="delete" size={24} color="red" />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <AntDesign name="leftcircleo" size={32} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>LISTA DE ITENS</Text>
        <TouchableOpacity style={styles.settingsButton}>
          <AntDesign name="setting" size={32} color="black" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={items}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        style={styles.list}
      />

      <View style={styles.bottomButtons}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteAllButton]}
          onPress={() => setItems([])}
        >
          <Text style={styles.buttonText}>EXCLUIR ITEM</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.actionButton, styles.addButton]}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.buttonText}>ADICIONAR ITEM</Text>
        </TouchableOpacity>
      </View>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Adicionar Item</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Nome do item"
              value={newItemName}
              onChangeText={setNewItemName}
            />

            <TextInput
              style={styles.input}
              placeholder="Valor (R$)"
              value={newItemValue}
              onChangeText={handleValueChange}
              keyboardType="decimal-pad"
            />

            <TextInput
              style={styles.input}
              placeholder="Quantidade"
              value={newItemQuantity}
              onChangeText={handleQuantityChange}
              keyboardType="number-pad"
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setModalVisible(false);
                  setNewItemName("");
                  setNewItemValue("");
                  setNewItemQuantity("");
                }}
              >
                <Text style={styles.buttonText}>Cancelar</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handleAddItem}
              >
                <Text style={styles.buttonText}>Adicionar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}; 