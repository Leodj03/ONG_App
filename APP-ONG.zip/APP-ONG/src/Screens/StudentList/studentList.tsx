import { View, TouchableOpacity, Text, FlatList, ActivityIndicator } from "react-native";
import { styles } from "./style";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useRouter } from "expo-router";
import { useState, useEffect } from "react";
import { Student, studentService } from "@/src/services/api";

export const StudentList = () => {
  const router = useRouter();
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadStudents();
  }, []);

  const loadStudents = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await studentService.getStudents();
      setStudents(data);
    } catch (err) {
      setError('Erro ao carregar alunos. Tente novamente.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAttendance = async (studentId: string, isPresent: boolean) => {
    try {
      await studentService.updateAttendance(studentId, isPresent);
      setStudents(students.map(student => 
        student.id === studentId ? { ...student, isPresent } : student
      ));
    } catch (err) {
      console.error(err);
      // Você pode adicionar um feedback visual do erro aqui
    }
  };

  const renderStudent = ({ item }: { item: Student }) => (
    <View style={styles.studentContainer}>
      <Text style={styles.studentName}>{item.name}</Text>
      <View style={styles.actionButtons}>
        <TouchableOpacity 
          style={[styles.actionButton, item.isPresent === false && styles.selectedRed]}
          onPress={() => handleAttendance(item.id, false)}
        >
          <AntDesign name="close" size={24} color={item.isPresent === false ? "white" : "red"} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.actionButton, item.isPresent === true && styles.selectedGreen]}
          onPress={() => handleAttendance(item.id, true)}
        >
          <AntDesign name="check" size={24} color={item.isPresent === true ? "white" : "green"} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
        <AntDesign name="leftcircleo" size={32} color="black" />
      </TouchableOpacity>

      <TouchableOpacity style={styles.settingsButton}>
        <AntDesign name="setting" size={32} color="black" />
      </TouchableOpacity>

      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color="#FFB347" />
        </View>
      ) : error ? (
        <View style={styles.centerContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={loadStudents}>
            <Text style={styles.retryButtonText}>Tentar Novamente</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={students}
          renderItem={renderStudent}
          keyExtractor={item => item.id}
          style={styles.list}
          refreshing={loading}
          onRefresh={loadStudents}
        />
      )}

      <TouchableOpacity style={styles.editButton}>
        <Text style={styles.editButtonText}>Editar Aluno</Text>
      </TouchableOpacity>
    </View>
  );
}; 