import React from 'react';
import { Home } from '../src/Screens/Home/home';


export default function HomeScreen() {
    return < Home />
    
}