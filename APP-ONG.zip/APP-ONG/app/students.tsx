import { StudentList } from "@/src/Screens/StudentList/studentList";

export default function StudentsScreen() {
  return <StudentList />;
} 