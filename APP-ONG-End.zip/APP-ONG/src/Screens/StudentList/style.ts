import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  titulo: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#000",
    textAlign: "center",
    marginTop: 80,
    marginBottom: 20,
  },
  botaoVoltar: {
    position: "absolute",
    top: 40,
    left: 20,
    zIndex: 1,
  },
  botaoConfig: {
    position: "absolute",
    top: 40,
    right: 20,
    zIndex: 1,
  },
  lista: {
    marginTop: 20,
  },
  containerAluno: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
    backgroundColor: "#fff",
  },
  nomeAluno: {
    fontSize: 16,
    color: "#000",
    flex: 1,
  },
  botoesAcao: {
    flexDirection: "row",
    gap: 10,
  },
  botaoAcao: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
  },
  selecionadoVermelho: {
    backgroundColor: "red",
    borderColor: "red",
  },
  selecionadoVerde: {
    backgroundColor: "green",
    borderColor: "green",
  },
  botaoEditar: {
    position: "absolute",
    bottom: 20,
    right: 20,
    backgroundColor: "#FFB347",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 25,
  },
  textoBotaoEditar: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "bold",
  },
}); 