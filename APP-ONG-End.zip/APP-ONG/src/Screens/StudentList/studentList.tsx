import { View, TouchableOpacity, Text, FlatList } from "react-native";
import { styles } from "./style";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useRouter } from "expo-router";
import { useState } from "react";

type Aluno = {
  id: string;
  nome: string;
  presente: boolean | null;
};

const dadosAlunos: Aluno[] = [
  { id: '1', nome: 'Leonardo Jesus', presente: null },
  { id: '2', nome: 'Pedro Henrique', presente: null },
  { id: '3', nome: 'Bryan Leal', presente: null },
  { id: '4', nome: 'Ana Carolina Silva', presente: null },
  { id: '5', nome: 'Gabriel Oliveira', presente: null },
  { id: '6', nome: 'Mariana Santos', presente: null },
  { id: '7', nome: 'Lucas Ferreira', presente: null },
  { id: '8', nome: 'Isabella Costa', presente: null },
  { id: '9', nome: 'Thiago Almeida', presente: null },
  { id: '10', nome: 'Juliana Pereira', presente: null },
  { id: '11', nome: 'Rafael Souza', presente: null },
  { id: '12', nome: 'Beatriz Lima', presente: null },
  { id: '13', nome: 'Felipe Rodrigues', presente: null },
  { id: '14', nome: 'Camila Martins', presente: null },
  { id: '15', nome: 'Diego Carvalho', presente: null }
];

export const StudentList = () => {
  const router = useRouter();
  const [alunos, setAlunos] = useState<Aluno[]>(dadosAlunos);

  const marcarPresenca = (alunoId: string, presente: boolean) => {
    setAlunos(alunos.map(aluno => 
      aluno.id === alunoId ? { ...aluno, presente } : aluno
    ));
  };

  const renderizarAluno = ({ item }: { item: Aluno }) => (
    <View style={styles.containerAluno}>
      <Text style={styles.nomeAluno}>{item.nome}</Text>
      <View style={styles.botoesAcao}>
        <TouchableOpacity 
          style={[styles.botaoAcao, item.presente === false && styles.selecionadoVermelho]}
          onPress={() => marcarPresenca(item.id, false)}
        >
          <AntDesign name="close" size={20} color={item.presente === false ? "white" : "red"} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.botaoAcao, item.presente === true && styles.selecionadoVerde]}
          onPress={() => marcarPresenca(item.id, true)}
        >
          <AntDesign name="check" size={20} color={item.presente === true ? "white" : "green"} />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.botaoVoltar} onPress={() => router.push("/")}>
        <AntDesign name="leftcircleo" size={32} color="black" />
      </TouchableOpacity>

      <TouchableOpacity style={styles.botaoConfig}>
        <AntDesign name="setting" size={32} color="black" />
      </TouchableOpacity>

      <Text style={styles.titulo}>Lista de Chamadas</Text>

      <FlatList
        data={alunos}
        renderItem={renderizarAluno}
        keyExtractor={item => item.id}
        style={styles.lista}
      />

      <TouchableOpacity 
        style={styles.botaoEditar}
        onPress={() => router.push("/editar-aluno")}
      >
        <Text style={styles.textoBotaoEditar}>Editar Aluno</Text>
      </TouchableOpacity>
    </View>
  );
}; 