import { View, TouchableOpacity, Text, ScrollView } from "react-native";
import { styles } from "./styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useRouter } from "expo-router";
import { useState } from "react";

type Aluno = {
  id: string;
  nome: string;
  notas: (number | null)[];
  media: number | null;
};

const alunosIniciais: Aluno[] = [
  { id: '1', nome: 'Ana Paula Silva', notas: [null, null, null, null, null], media: null },
  { id: '2', nome: 'João Marcos Oliveira', notas: [null, null, null, null, null], media: null },
  { id: '3', nome: 'Luana Ferreira', notas: [null, null, null, null, null], media: null },
  { id: '4', nome: 'Pedro Henrique Santos', notas: [null, null, null, null, null], media: null },
  { id: '5', nome: 'Maria Eduarda Costa', notas: [null, null, null, null, null], media: null },
  { id: '6', nome: 'Rafael Lima', notas: [null, null, null, null, null], media: null },
  { id: '7', nome: 'Beatriz Almeida', notas: [null, null, null, null, null], media: null },
  { id: '8', nome: 'Lucas Matheus Rocha', notas: [null, null, null, null, null], media: null },
  { id: '9', nome: 'Camila Soares', notas: [null, null, null, null, null], media: null },
  { id: '10', nome: 'Gabriel Aciates', notas: [null, null, null, null, null], media: null }
];

export const AtribuirNota = () => {
  const router = useRouter();
  const [alunos, setAlunos] = useState<Aluno[]>(alunosIniciais);

  const calcularMedia = (notas: (number | null)[]) => {
    const notasValidas = notas.filter((nota): nota is number => nota !== null);
    if (notasValidas.length === 0) return null;
    return notasValidas.reduce((a, b) => a + b, 0) / notasValidas.length;
  };

  const atribuirNota = (alunoId: string, notaIndex: number, valor: number) => {
    if (valor < 0 || valor > 10) return;
    
    setAlunos(alunos.map(aluno => {
      if (aluno.id === alunoId) {
        const novasNotas = [...aluno.notas];
        novasNotas[notaIndex] = valor;
        return {
          ...aluno,
          notas: novasNotas,
          media: calcularMedia(novasNotas)
        };
      }
      return aluno;
    }));
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.botaoVoltar} onPress={() => router.push("/")}>
        <AntDesign name="leftcircleo" size={32} color="black" />
      </TouchableOpacity>

      <TouchableOpacity style={styles.botaoConfig}>
        <AntDesign name="setting" size={32} color="black" />
      </TouchableOpacity>

      <ScrollView style={styles.tabelaContainer}>
        <View style={styles.cabecalho}>
          <Text style={styles.colunaNome}>Aluno</Text>
          <Text style={styles.colunaNota}>Nota1</Text>
          <Text style={styles.colunaNota}>Nota2</Text>
          <Text style={styles.colunaNota}>Nota3</Text>
          <Text style={styles.colunaNota}>Nota4</Text>
          <Text style={styles.colunaNota}>Nota5</Text>
          <Text style={styles.colunaMedia}>Média</Text>
        </View>

        {alunos.map((aluno) => (
          <View key={aluno.id} style={styles.linha}>
            <Text style={styles.colunaNome}>{aluno.nome}</Text>
            {aluno.notas.map((nota, index) => (
              <TouchableOpacity 
                key={index}
                style={styles.celulaNota}
                onPress={() => {
                  const novaNota = parseFloat(prompt('Digite a nota (0-10):') || '');
                  if (!isNaN(novaNota)) {
                    atribuirNota(aluno.id, index, novaNota);
                  }
                }}
              >
                <Text style={styles.textoNota}>
                  {nota !== null ? nota.toFixed(1) : '-'}
                </Text>
              </TouchableOpacity>
            ))}
            <Text style={styles.colunaMedia}>
              {aluno.media !== null ? aluno.media.toFixed(1) : '-'}
            </Text>
          </View>
        ))}
      </ScrollView>

      <TouchableOpacity style={styles.botaoAtribuir}>
        <Text style={styles.textoBotao}>ATRIBUIR NOTA</Text>
      </TouchableOpacity>
    </View>
  );
}; 