import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  botaoVoltar: {
    position: "absolute",
    top: 40,
    left: 20,
    zIndex: 1,
  },
  botaoConfig: {
    position: "absolute",
    top: 40,
    right: 20,
    zIndex: 1,
  },
  tabelaContainer: {
    marginTop: 100,
    flex: 1,
  },
  cabecalho: {
    flexDirection: "row",
    backgroundColor: "#4F6F52",
    padding: 10,
    marginBottom: 1,
  },
  linha: {
    flexDirection: "row",
    backgroundColor: "#F5F5F5",
    padding: 10,
    marginBottom: 1,
    alignItems: "center",
  },
  colunaNome: {
    flex: 2,
    color: "#000",
    fontSize: 14,
  },
  colunaNota: {
    flex: 1,
    textAlign: "center",
    color: "#FFF",
    fontSize: 14,
    fontWeight: "bold",
  },
  colunaMedia: {
    flex: 1,
    textAlign: "center",
    color: "#000",
    fontSize: 14,
    fontWeight: "bold",
  },
  celulaNota: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 5,
  },
  textoNota: {
    color: "#000",
    fontSize: 14,
  },
  botaoAtribuir: {
    backgroundColor: "#FFB347",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 25,
    alignSelf: "center",
    marginTop: 20,
    marginBottom: 20,
  },
  textoBotao: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "bold",
  },
}); 