import React, { useState } from "react";
import { View, TouchableOpacity, Text, TextInput, ScrollView } from "react-native";
import { styles } from "./style";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useRouter } from "expo-router";

type Student = {
  id: string;
  name: string;
  grades: number[];
};

export const GradeScreen = () => {
  const router = useRouter();
  const [students, setStudents] = useState<Student[]>([
    { id: "1", name: "Ana Silva", grades: [0, 0, 0, 0] },
    { id: "2", name: "Bruno Santos", grades: [0, 0, 0, 0] },
    { id: "3", name: "Carla Oliveira", grades: [0, 0, 0, 0] },
    { id: "4", name: "Daniel Lima", grades: [0, 0, 0, 0] },
    { id: "5", name: "Elena Costa", grades: [0, 0, 0, 0] },
    { id: "6", name: "Fábio Pereira", grades: [0, 0, 0, 0] },
    { id: "7", name: "Gabriela Martins", grades: [0, 0, 0, 0] },
    { id: "8", name: "Hugo Ferreira", grades: [0, 0, 0, 0] },
    { id: "9", name: "Isabel Rodrigues", grades: [0, 0, 0, 0] },
    { id: "10", name: "João Almeida", grades: [0, 0, 0, 0] },
    { id: "11", name: "Karina Santos", grades: [0, 0, 0, 0] },
    { id: "12", name: "Lucas Ribeiro", grades: [0, 0, 0, 0] },
    { id: "13", name: "Maria Souza", grades: [0, 0, 0, 0] },
    { id: "14", name: "Nuno Costa", grades: [0, 0, 0, 0] },
    { id: "15", name: "Olívia Lima", grades: [0, 0, 0, 0] },
  ]);

  const handleGradeChange = (studentId: string, gradeIndex: number, value: string) => {
    const numValue = Number(value);
    if (isNaN(numValue) || numValue < 0 || numValue > 10) return;
    
    setStudents(prevStudents => 
      prevStudents.map(student => 
        student.id === studentId 
          ? {
              ...student,
              grades: student.grades.map((g, i) => 
                i === gradeIndex ? numValue : g
              )
            }
          : student
      )
    );
  };

  const calculateAverage = (grades: number[]) => {
    const sum = grades.reduce((acc, grade) => acc + grade, 0);
    return (sum / grades.length).toFixed(1);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={() => router.navigate("/")}>
        <AntDesign name="leftcircleo" size={32} color="black" />
      </TouchableOpacity>

      <TouchableOpacity style={styles.settingsButton}>
        <AntDesign name="setting" size={32} color="black" />
      </TouchableOpacity>

      <Text style={styles.title}>Boletim Escolar</Text>

      <View style={styles.tableHeader}>
        <Text style={styles.nameHeader}>Aluno</Text>
        <Text style={styles.gradeHeader}>N1</Text>
        <Text style={styles.gradeHeader}>N2</Text>
        <Text style={styles.gradeHeader}>N3</Text>
        <Text style={styles.gradeHeader}>N4</Text>
        <Text style={styles.gradeHeader}>Média</Text>
      </View>

      <ScrollView style={styles.tableContent}>
        {students.map((student) => (
          <View key={student.id} style={styles.tableRow}>
            <Text style={styles.nameCell}>{student.name}</Text>
            {student.grades.map((grade, index) => (
              <TextInput
                key={index}
                style={styles.gradeInput}
                value={grade.toString()}
                onChangeText={(value) => handleGradeChange(student.id, index, value)}
                keyboardType="numeric"
                maxLength={2}
              />
            ))}
            <Text style={styles.averageCell}>
              {calculateAverage(student.grades)}
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}; 