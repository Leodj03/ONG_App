import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  backButton: {
    position: "absolute",
    top: 40,
    left: 20,
    zIndex: 1,
  },
  settingsButton: {
    position: "absolute",
    top: 40,
    right: 20,
    zIndex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#000",
    textAlign: "center",
    marginTop: 80,
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#FFB347",
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },
  nameHeader: {
    flex: 2,
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  gradeHeader: {
    flex: 1,
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    textAlign: "center",
  },
  tableContent: {
    flex: 1,
  },
  tableRow: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
    alignItems: "center",
  },
  nameCell: {
    flex: 2,
    fontSize: 14,
    color: "#000",
  },
  gradeInput: {
    flex: 1,
    height: 40,
    backgroundColor: "#F5F5F5",
    borderRadius: 8,
    textAlign: "center",
    marginHorizontal: 2,
    fontSize: 14,
    color: "#000",
  },
  averageCell: {
    flex: 1,
    fontSize: 14,
    color: "#000",
    textAlign: "center",
    fontWeight: "bold",
  },
}); 