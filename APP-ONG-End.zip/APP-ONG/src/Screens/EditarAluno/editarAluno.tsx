import { View, TouchableOpacity, Text, TextInput, Image } from "react-native";
import { styles } from "./styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useRouter } from "expo-router";

export const EditarAluno = () => {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.botaoVoltar} onPress={() => router.push("/students")}>
        <AntDesign name="leftcircleo" size={32} color="black" />
      </TouchableOpacity>

      <TouchableOpacity style={styles.botaoConfig}>
        <AntDesign name="setting" size={32} color="black" />
      </TouchableOpacity>

      <View style={styles.containerFoto}>
        <Image 
          source={require("../../images/profile.png")}
          style={styles.foto}
        />
      </View>

      <View style={styles.formulario}>
        <TextInput
          style={styles.input}
          placeholder="NOME"
          placeholderTextColor="#FFF"
        />
        <TextInput
          style={styles.input}
          placeholder="SOBRENOME"
          placeholderTextColor="#FFF"
        />
        <TextInput
          style={styles.input}
          placeholder="CPF / RG"
          placeholderTextColor="#FFF"
        />
        <TextInput
          style={styles.input}
          placeholder="DATA DE NASCIMENTO"
          placeholderTextColor="#FFF"
        />
        <TextInput
          style={styles.input}
          placeholder="ENDEREÇO"
          placeholderTextColor="#FFF"
        />
        <TextInput
          style={styles.input}
          placeholder="NOME PAI OU MÃE"
          placeholderTextColor="#FFF"
        />
      </View>

      <View style={styles.containerBotoes}>
        <TouchableOpacity style={styles.botaoExcluir}>
          <Text style={styles.textoBotao}>EXCLUIR</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botaoAlterar}>
          <Text style={styles.textoBotao}>ALTERAR</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}; 