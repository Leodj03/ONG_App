import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  botaoVoltar: {
    position: "absolute",
    top: 40,
    left: 20,
    zIndex: 1,
  },
  botaoConfig: {
    position: "absolute",
    top: 40,
    right: 20,
    zIndex: 1,
  },
  containerFoto: {
    alignItems: "center",
    marginTop: 100,
    marginBottom: 30,
  },
  foto: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "#E0E0E0",
  },
  formulario: {
    width: "100%",
    gap: 15,
  },
  input: {
    width: "100%",
    height: 45,
    backgroundColor: "#000",
    borderRadius: 8,
    paddingHorizontal: 15,
    color: "#fff",
    fontSize: 14,
  },
  containerBotoes: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 30,
    paddingHorizontal: 20,
  },
  botaoExcluir: {
    backgroundColor: "#000",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 25,
  },
  botaoAlterar: {
    backgroundColor: "#FFB347",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 25,
  },
  textoBotao: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "bold",
  },
}); 