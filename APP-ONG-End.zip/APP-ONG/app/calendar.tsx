import { Calendar } from "@/src/Screens/Calendar/calendar";


export default function CalendarScreen() {
  return <Calendar/>
  
}