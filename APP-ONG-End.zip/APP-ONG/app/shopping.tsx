import { ShoppingList } from "@/src/Screens/ShoppingList/shoppingList";

export default function ShoppingScreen() {
  return <ShoppingList />;
} 