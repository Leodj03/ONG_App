import { Maps } from "@/src/Screens/Maps/maps";
import React from "react";


export default function MapsScreen() {
    return < Maps />

}