import { EditarAluno } from "@/src/Screens/EditarAluno/editarAluno";

export default function EditarAlunoScreen() {
  return <EditarAluno />;
} 