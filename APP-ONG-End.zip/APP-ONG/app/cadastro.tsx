import { Cadastro } from "@/src/Screens/Cadastro/cadastro";



export default function CadastrarScreen(){
    return <Cadastro/>
}