import { GradeScreen } from "@/src/Screens/Grades/grades";

export default function GradesScreen() {
  return <GradeScreen />;
} 