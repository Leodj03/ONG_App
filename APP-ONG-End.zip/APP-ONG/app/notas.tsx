import { AtribuirNota } from "@/src/Screens/AtribuirNota/atribuirNota";

export default function NotasScreen() {
  return <AtribuirNota />;
} 